
# Trivia Game - How to Run

This is a console-based trivia game written in C++.

## 🛠 Prerequisites
- A C++ compiler (e.g., g++, MSVC)
- Windows system (uses `conio.h`, `windows.h`)
- Command line interface (CMD or terminal)

## ▶️ How to Compile
To compile the game using `g++`, open terminal and run:

```bash
g++ Trivia.cpp -o trivia_game
```

## 🚀 How to Play
Run the game after compiling:

```bash
./trivia_game
```

- You’ll be prompted to enter your name.
- Read the terms and conditions carefully.
- Answer the questions by typing A, B, C, or D.
- Use lifelines: `H` for Pay Half & Skip and `L` for Leave Question.
- Game ends if your balance drops below zero or all questions are attempted.
- Results are shown in a styled result card at the end.

